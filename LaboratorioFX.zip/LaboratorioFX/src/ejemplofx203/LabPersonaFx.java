package ejemplofx203;

import javafx.beans.property.SimpleStringProperty;

public class LabPersonaFx {
    private SimpleStringProperty nombre = new SimpleStringProperty();
    private SimpleStringProperty paterno = new SimpleStringProperty();
    private SimpleStringProperty materno = new SimpleStringProperty();
    private SimpleStringProperty fecha = new SimpleStringProperty();
    
    @Override
    public String toString() {
        return getNombre().getValue()+" "+getPaterno().getValue()+" "+getMaterno().getValue()+" $"+getFecha().get();
    }

    public SimpleStringProperty getNombre() {
        return nombre;
    }

    public void setNombre(SimpleStringProperty nombre) {
        this.nombre = nombre;
    }

    public SimpleStringProperty getPaterno() {
        return paterno;
    }

    public void setPaterno(SimpleStringProperty paterno) {
        this.paterno = paterno;
    }

    public SimpleStringProperty getMaterno() {
        return materno;
    }

    public void setMaterno(SimpleStringProperty materno) {
        this.materno = materno;
    }
     
    public SimpleStringProperty getFecha() {
        return fecha;
    }

    public void setFecha(SimpleStringProperty fecha) {
        this.fecha = fecha;
    }
}
