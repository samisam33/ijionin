package ejemplofx203;

import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class FXMLDocumentController implements Initializable {
    
    LabPersonaFx p = new LabPersonaFx();
    SimpleStringProperty nombre = new SimpleStringProperty();
    SimpleStringProperty apellidoP = new SimpleStringProperty();
    SimpleStringProperty apellidoM = new SimpleStringProperty();
    
    
    private int idioma = 0;
    private Stage stage;
    @FXML
    private Label label;
    @FXML
    private Button button;
    @FXML
    private Label labelP;
    @FXML
    private Label labelM;
    @FXML
    private Label labelF;
    @FXML
    private Label label1;
    @FXML
    private Label label2;
    @FXML
    private Label label3;
    @FXML
    private Label label4;
    @FXML
    private TextField textoO;
    @FXML
    private TextField textoN;
    @FXML
    private TextField textoP;
    @FXML
    private TextField textoM;
    @FXML
    private DatePicker textoF;
    @FXML
    private Button botonOk;
    
    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
        setIdioma(Integer.parseInt(textoO.getText()));
        
            if (getIdioma() == 1) {
                Locale.setDefault(new Locale("es"));
            } else if (getIdioma() == 2) {
                Locale.setDefault(new Locale("en"));
            } else if (getIdioma() == 3){
                Locale.setDefault(new Locale("fra"));
            } else if (getIdioma() == 4){
                Locale.setDefault(new Locale("ita"));
            } else if (getIdioma() == 5){
                Locale.setDefault(new Locale("na"));
            } else {
                System.out.println("Datos erroneos");
            }
        
        ResourceBundle boncheRecursos;
        boncheRecursos = ResourceBundle.getBundle("recursos.idiomas");
        FXMLLoader loader = new FXMLLoader (getClass().getResource("FXMLDocument.fxml"),boncheRecursos);
        
        Parent root = loader.load();
        FXMLDocumentController controlador = loader.getController();
        controlador.setStage(stage);
        controlador.setIdioma(idioma);
        
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    private void guardarButtonAction(ActionEvent event) throws IOException {
        System.out.println(p);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        label1.textProperty().bindBidirectional(textoN.textProperty());
        nombre.bindBidirectional(textoN.textProperty());
        label2.textProperty().bindBidirectional(textoP.textProperty());
        apellidoP.bindBidirectional(textoP.textProperty());
        label3.textProperty().bindBidirectional(textoM.textProperty());
        apellidoM.bindBidirectional(textoM.textProperty());
        //label4.textProperty().bindBidirectional(textoF.promptTextProperty());
        //fechaN.bindBidirectional(textoF.promptTextProperty());
        
        p.getNombre().bindBidirectional(textoN.textProperty());
        p.getPaterno().bindBidirectional(textoP.textProperty());
        p.getMaterno().bindBidirectional(textoM.textProperty());
        p.getFecha().bindBidirectional(textoF.promptTextProperty());
    }    

    public Stage getStage() {
        return stage;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public int getIdioma() {
        return idioma;
    }
    public void setIdioma(int idioma) {
        this.idioma = idioma;
    }
    
}
